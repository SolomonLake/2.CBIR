from PIL import Image
import webbrowser
import sys
import random
import math
import time
import numpy
import histodict

#Image.eval(image, function) this will be useful later



class MyImage:
    def __init__(self,fname,method):
        # open image
        self.im = Image.open(fname)
        print 'Image read from', fname, 'with size', self.im.size
        self.size = self.im.size
        self.pixels = self.size[0] * self.size[1]
        # get data from image
        self.data = list(self.im.getdata())
        self.h= self.im.histogram()
        #histofile = open('histodict.txt', 'r+') may not need this line
        self.histograms = histodict.dict
        print 'Dictionary of Histograms imported'
        if method == 1:
            self.distances()
        if method == 2:
            self.intersection()


    def compare(self,mainimage,secondimage):
        total = 0
        hist2 = self.histograms[secondimage]
        for i in range(len(hist2)):
            a = (hist2[i]-self.h[i])**2
            total += a
        return math.sqrt(total)

    def distances(self):
        self.distancewith = []
        for i in self.histograms:
            a = self.compare(self.im,i)
            a = math.floor(a)
            self.distancewith.append([int(a),i])
        self.radixsort(self.distancewith)

    def compareintersect(self, secondimage):
        total = 0
        maxtotal = 0
        hist2 = self.histograms[secondimage]
        """
        secondsize = Image.open(secondimage).size
        secondpixels = secondsize[0] * secondsize[1]
        multiplyer = float(self.pixels) / float(secondpixels)
        """
        for i in range(len(hist2)):
                #holder=float(hist2[i])*multiplyer
                if hist2[i]<self.h[i]:
                        a = hist2[i]
                        total += a
                        maxtotal+=self.h[i]
                else:
                        total+=self.h[i]
                        maxtotal+=hist2[i]
        #print (float(total))
        return (float(total))

    def intersection(self):
        self.intersections = []
        for i in self.histograms:
                a = self.compareintersect(i)
                a*=1000
                a = math.floor(a)*-1
                self.intersections.append([int(a),i])
        self.radixsort(self.intersections)


        
    def radixsort(self,aList):
        RADIX = 10
        maxLength = False
        tmp , placement = -1, 1

        while not maxLength:
            maxLength = True
            # declare and initialize buckets
            buckets = [list() for _ in range(RADIX)]

            # split aList between lists
            for i in aList:
                tmp = i[0] / placement
                buckets[tmp % RADIX].append(i)
                if maxLength and tmp > 0:
                    maxLength = False

            # empty lists into aList array
            a = 0
            for b in range(RADIX):
                buck = buckets[b]
                for i in buck:
                    aList[a] = i
                    a += 1
            # move to next digit
            placement *= RADIX

#i = MyImage('20496.jpg', 2)
#print i.intersections[:20]


"""

    def exch(a, i, j):
        swap = a[i]
    a[i] = a[j]
    a[j] = swap

    def partition(a, lo, hi):
    i = lo + 1
    j = hi
    while 1:
        while i <= j and a[i] <= a[lo]:
            i += 1
        while i <= j and a[lo] <= a[j]:
            j -= 1
        if i > j:
            break
        exch(a, i, j)
    exch(a, lo, j)
    return j

    def quick(a, lo, hi):
    if hi <= lo:
        return
    j = partition(a, lo, hi)
    quick(a, lo, j-1)
    quick(a, j+1, hi)

    def quicksort(a):
    random.shuffle(a)
    quick(a, 0, len(a)-1)

    def merge(a, aux, lo, mid, hi):
    for k in range(lo, hi+1):
        aux[k] = a[k]
    i = lo
    j = mid + 1
    for k in range(lo, hi+1):
        if i > mid:
            a[k] = aux[j]
            j += 1
        elif j > hi:
            a[k] = aux[i]
            i += 1
        elif aux[j] < aux[i]:
            a[k] = aux[j]
            j += 1
        else:
            a[k] = aux[i]
            i += 1

    def sort(a, aux, lo, hi):
    if hi <= lo:
        return
    mid = lo + (hi-lo)/2
    sort(a, aux, lo, mid)
    sort(a, aux, mid+1, hi)
    merge(a, aux, lo, mid, hi)

    def mergesort(a):
    aux = [0] * len(a)
    sort(a, aux, 0, len(a)-1)"""

#if __name__ == "__main__":
#i = MyImage('20001')

