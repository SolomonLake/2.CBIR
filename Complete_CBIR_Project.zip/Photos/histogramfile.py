from PIL import Image
import os

histogramdict = {}

for i in range (50000, 50095):
        photo = str(i) + ".jpg"
        spec_photo = Image.open(photo)
        histogramdict[photo] = spec_photo.histogram()

for i in range (20000, 20990):
        photo = str(i) + ".jpg"
        if os.path.isfile(photo):
                spec_photo = Image.open(photo)
                histogramdict[photo] = spec_photo.histogram()
        else:
                continue

file = open('histodict.txt', 'w')
file.write(str(histogramdict))
